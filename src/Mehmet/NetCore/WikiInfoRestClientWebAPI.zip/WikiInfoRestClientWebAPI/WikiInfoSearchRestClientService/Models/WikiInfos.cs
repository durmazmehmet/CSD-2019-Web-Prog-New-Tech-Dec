﻿using System.Collections.Generic;

namespace CSD.WikiInfoSearch.RestClientService.Models
{
    public class WikiInfos
    {
        public List<WikiInfo> Geonames { get; set; }
    }
}
